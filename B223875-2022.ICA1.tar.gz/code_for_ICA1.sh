mkdir $HOME/ICA1
mkdir $HOME/ICA1/fastq
mkdir $HOME/ICA1/submission
# This step is to make directories for the assignment

cp /localdisk/data/BPSM/ICA1/fastq $HOME/ICA1
cp /localdisk/data/BPSM/ICA1/fastq $HOME
cp -R /localdisk/data/BPSM/ICA1/fastq $HOME
cp -R /localdisk/data/BPSM/ICA1/fastq $HOME/ICA1
cp -R /localdisk/data/BPSM/ICA1/Tcongo_genome/ $HOME/ICA1
# This step is to copy the files into my own directories

cd $HOME/ICA1/fastq
fastqc *.fq.gzv
# This step is to use fastqc to analyse the raw data

mkdir fastqc
mv *.html
mv *.html fastqc
mv *.zip fastqc

cd fastqc
unzip Tco-5053_1_fastqc.zip
cd Tco-5053_1_fastqc
sed -n '8p' fastqc_data.txt | awk '{if($6==0) print "The sequence has good quality";else print "The sequence has bad quality"}' > record.txt && cat record.txt
# Unzip the fastqc result and access the data to show whether the sequence has good quality.

cd $HOME/ICA1/fastq
zcat Tco-5053_1.fq.gz | less
# Access the data from fastqc results
cd /localdisk/data/BPSM/ICA1/Tcongo_genome/

cd Tcongo_genome
gunzip TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz
less TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta

samtools faidx TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta

hisat2-build TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta TriTrypDB-46_TcongolenseIL3000_2019_Genome
less TriTrypDB-46_TcongolenseIL3000_2019_Genome.1.ht2
bowtie2-build TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta TriTrypDB-46_TcongolenseIL3000_2019_Genome
cd /localdisk/data/BPSM/ICA1/
cp TrypDB-46_TcongolenseIL3000_2019.bed
cp /localdisk/data/BPSM/ICA1/TriTrypDB-46_TcongolenseIL3000_2019.bed $HOME/ICA1
cd $HOME/ICA1
less TriTrypDB-46_TcongolenseIL3000_2019.bed
cd fastq/
# Set up the environment for Hisat2 or Bowtie2cd 

isat2 -x ../Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome -1 Tco-5053_1.fq.gz -2 Tco-5053_2.fq.gz -S Tco-5053.sam
ls | grep gz$ | sed 's/_.*$//' | sort -u | grep Tco | while read id;do hisat2 -x ../Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome -1 ${id}_1.fq.gz -2 ${id}_2.fq.gz -S ${id}.sam ;done
# This step is to write a loop to hisat2 all the fq.gz files

mkdir sam
mv *.sam sam
mkdir bam

ls sam | grep sam$ | sed 's/\.s.*$//' | sort -u | grep Tco | while read id;do samtools sort -o bam/${id}.bam -O BAM sam/${id}.sam; samtools index bam/${id}.bam; done
cd bam
# This step is to find and list out the sam files. After that, convert the sams files into bam files. 

samtools view Tco-5053.bam | less
bedtools multicov
bedtools multicov -bams *.bam -bed
bedtools multicov -bams *.bam -bed ../../TriTrypDB-46_TcongolenseIL3000_2019.bed > count.txt
# Aligning the regions using bedtools

awk '{print $6"\t"$7}' count.txt | less
awk -F "\t" '{print $6"\t"$7}' count.txt | less
less count.txt

grep -n Clone1 $HOME/ICA1/fastq/Tco.fqfiles
awk '{print ($8+$42+$49)/3}' count.txt > clone1-0-U.txt
awk '{print ($24+$36+$43)/3}' count.txt > clone1-24-U.txt
awk '{print ($20+$39+$45)/3}' count.txt > clone1-48-U.txt
awk '{print "N/A"}' count.txt > clone1-0-I.txt
awk '{print ($9+$35+$50+$54)/4}' count.txt > clone1-48-I.txt
awk '{print ($31+$47)/2}' count.txt > clone1-24-I.txt

grep -n Clone2 $HOME/ICA1/fastq/Tco.fqfiles
awk '{print ($7+$17+$18)}' count.txt > clone2-0-U.txt
awk '{print ($13+$16+$32+$51)/4}' count.txt > clone2-24-U.txt
awk '{print "N/A"}' count.txt > clone2-0-I.txt
awk '{print ($28+$30+$33)/3}' count.txt > clone2-48-U.txt
awk '{print ($10+$46+$48)/3}' count.txt > clone2-24-I.txt
awk '{print ($12+$38+$40)/3}' count.txt > clone2-48-I.txt

grep -n WT $HOME/ICA1/fastq/Tco.fqfiles
awk '{print ($21+$22+$53)/3}' count.txt > WT-0-U.txt
awk '{print ($29+$44+$52)/3}' count.txt > WT-24-U.txt
awk '{print ($26+$27+$34)/3}' count.txt > WT-48-U.txt
awk '{print "N/A"}' count.txt > WT-0-I.txt
awk '{print ($11+$14+$19+$41)/4}' count.txt > WT-24-I.txt
awk '{print ($15+$23+$25)/3}' count.txt > WT-48-I.txt
# Find the average counts for each type of gene


paste clone1-24-I.txt clone1-24-U.txt | awk '{if($2!=0) print $1/$2}'
paste clone1*.txt clone1*.txt | awk '{if($2!=0) print $1/$2}'
# Compare average counts for one gene to another to find the "fold change"